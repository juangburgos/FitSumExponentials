from ._cbor_diag import *

__doc__ = _cbor_diag.__doc__
__all__ = _cbor_diag.__all__
