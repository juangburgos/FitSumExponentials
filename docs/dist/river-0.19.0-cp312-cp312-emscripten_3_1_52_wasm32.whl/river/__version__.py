from __future__ import annotations

VERSION = (0, 19, 0)

__version__ = ".".join(map(str, VERSION))  # noqa: F401
