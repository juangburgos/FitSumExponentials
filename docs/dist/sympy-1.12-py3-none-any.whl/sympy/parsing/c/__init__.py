"""Used for translating C source code into a SymPy expression"""
